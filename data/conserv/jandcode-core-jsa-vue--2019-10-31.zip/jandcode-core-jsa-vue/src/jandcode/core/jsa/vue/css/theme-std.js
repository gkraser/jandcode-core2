import css from './theme-std.less'
import '[*]/css/module-std.js'

Jc.requireCss(css)

Jc.cfg.set({
    theme: {
        name: 'std'
    }
})
