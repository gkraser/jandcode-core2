let bc = 'jc-separator'

export default {
    name: bc,
    functional: true,

    render(h, ctx) {
        return h('div', {
            'class': bc,
        })
    }

}

