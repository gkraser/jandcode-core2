<template>
    <div :class="cn()">
        <slot></slot>
    </div>
</template>

<script>
    export default {
        name: 'jc-menu',

        props: {},

        data() {
            return {}
        }
    }
</script>

