<template>
    <tst-panel class="popupmodal1-test-c1014e4b">
        <PopupComp1 inlineComp="true"/>
    </tst-panel>
</template>

<script>
    import PopupComp1 from './comp/PopupComp1'

    export default {
        components: {
            PopupComp1,
        },
        props: {},
        data() {
            return {}
        }
    }
</script>

<style lang="less">

    .popupmodal1-test-c1014e4b {

    }

</style>
