//
import * as jsaBase from 'jandcode.core.jsa.base'
//
import Vue from 'vue'
import VueRouter from 'vue-router'

//
export {
    Vue,
    VueRouter,
    jsaBase,
}
