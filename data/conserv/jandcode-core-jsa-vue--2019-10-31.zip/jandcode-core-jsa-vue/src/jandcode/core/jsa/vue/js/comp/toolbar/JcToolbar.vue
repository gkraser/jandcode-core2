<template>
    <div :class="cn()">
        <slot></slot>
    </div>
</template>

<script>
    export default {
        name: 'jc-toolbar'
    }
</script>
