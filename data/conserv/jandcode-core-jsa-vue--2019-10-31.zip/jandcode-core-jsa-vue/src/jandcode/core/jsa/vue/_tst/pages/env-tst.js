import 'jandcode.core.jsa.vue'
import './svgicons'