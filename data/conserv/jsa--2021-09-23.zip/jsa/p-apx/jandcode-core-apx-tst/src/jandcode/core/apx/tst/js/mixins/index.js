import lorem from './lorem'
import cfgStore from './cfg-store'

export {
    lorem,
    cfgStore,
}

