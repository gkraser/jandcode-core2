
Фреймы для тестирования FrameManager

