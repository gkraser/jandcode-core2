import JcDecor from './JcDecor'

/**
 * Базовый предок для декораторов приложения.
 */
export default {

    extends: JcDecor,

    computed: {}

}
