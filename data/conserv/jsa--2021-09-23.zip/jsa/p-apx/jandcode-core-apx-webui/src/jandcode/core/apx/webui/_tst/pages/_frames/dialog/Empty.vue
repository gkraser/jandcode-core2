<template>
    <Dialog>
    </Dialog>
</template>

<script>
import {apx} from '../vendor'

export default {
    extends: apx.JcFrame,
    created() {
        this.title = 'Empty'
    },
    frameInit() {
    },
    data() {
        return {}
    },
    methods: {},
}
</script>
