//
window.quasarConfig = window.quasarConfig || {}
window.quasarConfig.loadingBar = window.quasarConfig.loadingBar || {}

window.quasarConfig.loadingBar.skipHijack = true

