//
import './quasar-config'
import {Quasar} from './vendor'

// глобализация
window.Quasar = Quasar

export {
    Quasar
}
