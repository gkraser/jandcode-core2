import * as a from 'jandcode.core.jsa'

console.info("a", a);
