
Инструменты для quasar
======================

* lib/postcss-pxtorem-fix.js - немного пофиксенная версия postcss-pxtorem 5.1.1
* quasar-css-pxtorem.js - Извлечение px-переменных из quasar.css и генерация на их основе
  less-файла для темы.
  
  