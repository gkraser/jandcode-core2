/* Тема base
----------------------------------------------------------------------------- */
import css from './base-theme.less'

let config = require('[*]/**/css/base-config.js')

export default {
    css: [css],
    config: config
}
