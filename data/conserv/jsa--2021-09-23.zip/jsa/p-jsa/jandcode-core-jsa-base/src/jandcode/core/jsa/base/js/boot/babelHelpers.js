// ЗАГЛУШКА!
console.error("babelHelpers not generated! Run 'jc jsa-build' or 'jc jsa-watch' and restart application");
