/*

jandcode-core-jsa-utils / vendor

----------------------------------------------------------------------------- */

import jQuery from 'jquery'
import axios from 'axios'
//
export {
    jQuery,
    axios,
}
