//
const p = require('jandcode.core.jsa.tools/jsa-gulp')
const g = new p.JsaGulpBuilder()

//
g.init(function(g) {
})
