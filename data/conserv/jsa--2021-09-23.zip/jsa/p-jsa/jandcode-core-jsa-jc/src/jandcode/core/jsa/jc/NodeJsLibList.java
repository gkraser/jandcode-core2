package jandcode.core.jsa.jc;

import jandcode.commons.named.*;

/**
 * Список библиотек nodejs
 */
public class NodeJsLibList extends DefaultNamedList<NodeJsLib> {
}
